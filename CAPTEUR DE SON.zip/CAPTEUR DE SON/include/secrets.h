/*
SSID du WIFI ainsi que le mot de passe
Modifier les paramètre WIFI pour le réseau auquels votre objets doit se brancher
*/

#define WIFI_SECRET_SSID "IDO"
#define WIFI_SECRET_PASS "99Bidules!"

/*
Information nécessaire pour le branchement a un Broker MQTT
Dans le cadre du cours AIIA1013, ne modifié pas cet information
*/

#define SECRET_MQTT_SERVER_IP "198.164.130.74"
#define SECRET_MQTT_SERVER_PORT 1883

/*
Détails sur l'indentification de l'objet
Cette information provient de l'objet virtuel créer sur le serveur Thingsbord
*/

#define SECRET_TOKEN  "QnQm15j7CeVSpM2gNeLN"
#define SECRET_DEVICE_ID "676f0bb0-74a5-11ed-8fd7-e3d583114459"



